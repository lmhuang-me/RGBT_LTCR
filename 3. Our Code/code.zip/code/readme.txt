The code is for paper "RGB-T Saliency Detection via Low-rank Tensor Learning and Unified Collaborative Ranking" 
By Liming Huang, Kechen Song, Aojun Gong, Chuang Liu, Yunhui Yan
https://github.com/lmhuang-me/RGBT_LTCR.git
******************************************************************************************************************
The code is tested on Windows10 with MATLAB R2018b.
******************************************************************************************************************
Usage:
>put the  images(included RGB and Thermal image) into file 'Img'
  The FCN-32S feature of RGB and Thermal image( https://github.com/DUTFangXiang/ExtractFCNFeature)
>put the FCN-32S features into file 'FCN-feature'
>run 'demo.m'

  For more quetions, please contact us.
  Email: huanglm.me@gmail.com